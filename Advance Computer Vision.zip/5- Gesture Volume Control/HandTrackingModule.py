import cv2
import mediapipe as mp
import time

# Now we will create class handDetector()

class handDetector():
    def __init__(self, mode=False, maxHands=2, detectionCon=0.5, trackCon=0.5):
        self.mode = mode
        self.maxHands = maxHands
        self.detectionCon = detectionCon
        self.trackCon = trackCon
        
        self.mpHands = mp.solutions.hands
        self.hands = self.mpHands.Hands(self.mode, self.maxHands, 
                                        self.detectionCon, self.trackCon)
        self.mpDraw = mp.solutions.drawing_utils

    
    def findHands(self, img, draw=True):
        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)  
        self.results = self.hands.process(imgRGB)
        #print(results.multi_hand_landmarks)  # see some process if detect hand

        # Extract the information of each hand to draw the dots & then draw the connections (21 dots)
        if self.results.multi_hand_landmarks:
            for handLms in self.results.multi_hand_landmarks:
                if draw:
                    self.mpDraw.draw_landmarks(img, handLms, 
                                               self.mpHands.HAND_CONNECTIONS)
        return img
    
    def findPosition(self, img, handNo=0, draw=True):
        lmList = []
        if self.results.multi_hand_landmarks:
            myHand = self.results.multi_hand_landmarks[handNo]
            # get id & lm(landmark) of dots in hand
            for id, lm in enumerate(myHand.landmark): 
                #print(id, lm)
                h, w, c = img.shape
                cx, cy = int(lm.x * w), int(lm.y * h)
                #print(id, cx, cy)  # get corodinate of each id(dots-21)
                lmList.append([id, cx, cy])
                if draw:
                    cv2.circle(img, (cx,cy), 7, (255,255,255), cv2.FILLED)
        return lmList
    
    

def main():
    pTime = 0   # Previous time
    cTime = 0   # Current time
    cap = cv2.VideoCapture(0)
    detector = handDetector()
    while(True):
        success, img = cap.read()
        #cv2.imshow('Image', img)
        img = cv2.flip(img, -1)    # flip the image/video 180 deg
        img = detector.findHands(img)
        lmList = detector.findPosition(img)
        if len(lmList) != 0:
            print(lmList[0])
        
        
      # Display the fps rate
        cTime = time.time()
        fps = 1/(cTime-pTime)
        pTime = cTime
        cv2.putText(img, str(int(fps)), (10,70), cv2.FONT_HERSHEY_PLAIN, 3,
                   (255, 0 , 255), 3)
    
    
        # Show the image         
        cv2.imshow('Image', img)
        if cv2.waitKey(1) & 0xFF == ord('q'):  # press q to exit the video
            break

        
    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()